public class Ex11 {
    public static void main(String[] args) {
        Matriz mat = new Matriz(5, 5);

        mat.preencheSemValorRepetido();

        System.out.println("Cartela de bingo");
        mat.mostraMatriz();
    }
}
