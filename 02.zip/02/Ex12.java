public class Ex12 {
    public static void main(String[] args) {
        Matriz gabarito = new Matriz(5, 10);


    }
}
