public class Ex13 {
    public static void main(String[] args) {
        
    }
}
