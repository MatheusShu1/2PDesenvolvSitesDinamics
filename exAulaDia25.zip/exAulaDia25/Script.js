const exercicios = require("./Exercicios.js")
module.exports = exercicios