const scripts = require("./Script.js")

//teste do ex 1
console.log("Exercicio 01")
console.log(scripts.exercicioUm(100, 4, 1))

//teste ex 2
console.log("-----------------------------")
console.log("Exercício 02")
scripts.exercicioDois(250)

//teste ex 3
console.log("-----------------------------")
console.log("Exercício 03")
scripts.exercicioTres(1990, 12500)

//teste ex 4
console.log("-----------------------------")
console.log("Exercício 04")
scripts.exercicioQuatro(1440, 103)

//teste ex 5
console.log("-----------------------------")
console.log("Exercício 05")
scripts.exercicioCinco(500)

// //teste ex 6
console.log("-----------------------------")
console.log("Exercício 06")
scripts.exercicioSeis(4, 8)